import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32
import math
import os
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

class ClosestObstaclePublisher(Node):
    def __init__(self):
        super().__init__('closest_obstacle_publisher')

        # Profilo QoS compatibile con Gazebo (BEST_EFFORT)
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',              # usa il nome esatto del topic
            self.laser_callback,
            qos_profile)


        self.publisher = self.create_publisher(Float32, '/obstacle', 10)
        self.min_dist_publisher = self.create_publisher(Float32, '/min_distance', 10)

        # Percorso del file di log
        self.log_file_path = os.path.expanduser('~/.ros/min_distance_log.txt')

        # Pulisce il file all'avvio (opzionale)
        with open(self.log_file_path, 'w') as f:
            f.write('')

    def flip_half_intervals(self,theta):
        if theta >= math.pi:
            return theta - 2*math.pi
        else:
            return theta


    def laser_callback(self, msg):
        min_distance = float('inf')
        min_angle = None

        global_min_distance = float('inf')

        angle = msg.angle_min

        for distance in msg.ranges:
            if math.isinf(distance) or math.isnan(distance):
                angle += msg.angle_increment
                continue

            # Distanza minima globale
            if distance < global_min_distance:
                global_min_distance = distance

            curr_angle = math.atan2(math.sin(angle), math.cos(angle)) 
            curr_angle = (curr_angle + math.pi) 
            curr_angle = self.flip_half_intervals(curr_angle)
            #self.get_logger().info(f"value={abs(math.sin(curr_angle) * distance):.2f}")
            if distance <= 1.5 and abs(math.sin(curr_angle) * distance) <= 0.25 + 0.25 * ((1.5 - distance) / 1.5) and -1.6 <= curr_angle <= 1.6: #1.5
                #self.get_logger().info("DISTANCE OK")
                if distance < min_distance:
                    #self.get_logger().info("UPDATE")
                    min_distance = distance
                    min_angle = curr_angle

            angle += msg.angle_increment

        if min_angle is None:
            angle_to_publish = 3.0
        else:
            angle_to_publish = min_angle

        msg_out = Float32()
        msg_out.data = float(angle_to_publish)
        self.publisher.publish(msg_out)

        min_dist_value = float(global_min_distance) if global_min_distance != float('inf') else 10.0

        # Pubblica su /min_distance
        min_dist_msg = Float32()
        min_dist_msg.data = min_dist_value
        self.min_dist_publisher.publish(min_dist_msg)
        #self.get_logger().info(f"min_dist_value={min_dist_value:.2f},angle_to_publish={float(angle_to_publish)}|")
        # ✅ Scrive nel file la distanza minima
        with open(self.log_file_path, 'a') as f:
            f.write(f"{min_dist_value:.4f}\n")

def main(args=None):
    rclpy.init(args=args)
    node = ClosestObstaclePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
